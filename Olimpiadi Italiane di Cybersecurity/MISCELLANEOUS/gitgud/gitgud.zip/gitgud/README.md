# Capitalize-inator 9000

![logo](ilovegraphicdesign.png)

this program takes a string and makes it uppercase!

to use this:

1. install python
2. open the folder
3. run python main.py and put the number of strings u want to use
4. insert your string(s)
5. have fun!!!!!

## credits

me
